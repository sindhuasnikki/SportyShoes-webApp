package com.ecommerce.Sportyshoes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.Sportyshoes.model.PurchaseOrder;

public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder, Long> {

}
