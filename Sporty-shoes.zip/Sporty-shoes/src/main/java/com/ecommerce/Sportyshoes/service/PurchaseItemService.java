package com.ecommerce.Sportyshoes.service;

import java.util.List;

import com.ecommerce.Sportyshoes.model.PurchaseItem;
import com.ecommerce.Sportyshoes.model.PurchaseOrder;
import com.ecommerce.Sportyshoes.model.User;



public interface PurchaseItemService {

	public PurchaseItem getPurchaseItemById(Long id);

	public List<PurchaseItem> getAllItemsByPurchaseOrder(PurchaseOrder order);

	public List<PurchaseItem> getAllPurchaseItemByUserId(User userId);

	public PurchaseItem savePurchaseItem(PurchaseItem purchaseItem);

	public List<PurchaseItem> getAllPurchaseItemList();

}
