package com.ecommerce.Sportyshoes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.Sportyshoes.service.ProductService;



@RestController
public class ProductController {

		@Autowired
		private ProductService productService;
}
